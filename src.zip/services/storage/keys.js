export const STORAGE_KEYS = {
  PUBLIC_USER_MODE: 'sporhive_public_user_mode',
  PUBLIC_USER: 'sporhive_public_user',
  PUBLIC_USER_TOKEN: 'sporhive_public_user_token',
  PLAYGROUNDS_CLIENT: 'sporhive_playgrounds_client',
  BOOKING_DRAFT: 'sporhive_playgrounds_booking_draft',
};
