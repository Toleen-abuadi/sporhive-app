import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { portalApi } from './portal.api';
import { portalStore, usePortal as usePortalContext } from './portal.store';
import { normalizeUniformOrders } from './portal.normalize';

export function usePortalAuth() {
  return usePortalContext();
}

export function usePortalOverview() {
  const [state, setState] = useState(portalStore.getState());
  const mounted = useRef(true);

  useEffect(() => {
    mounted.current = true;
    const unsub = portalStore.subscribe((next) => {
      if (mounted.current) setState(next);
    });

    if (!portalStore.getState().overview && !portalStore.getState().loading) {
      portalStore.loadOverview();
    }

    return () => {
      mounted.current = false;
      unsub?.();
    };
  }, []);

  const refresh = useCallback(async () => portalStore.refreshOverview(), []);

  return { ...state, refresh };
}

export function usePortalRefresh() {
  const [refreshing, setRefreshing] = useState(false);

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    try {
      await portalStore.refreshOverview();
    } finally {
      setRefreshing(false);
    }
  }, []);

  return { refreshing, onRefresh };
}

export function usePortalRenewals() {
  const { submitRenewal, checkRenewalsEligibility } = usePortalAuth();
  const [eligibility, setEligibility] = useState(null);
  const [loading, setLoading] = useState(false);

  const checkEligibility = useCallback(async () => {
    setLoading(true);
    const res = await checkRenewalsEligibility();
    if (res?.success) setEligibility(res.data?.data || res.data);
    setLoading(false);
    return res;
  }, [checkRenewalsEligibility]);

  const requestRenewal = useCallback(async () => {
    setLoading(true);
    const res = await submitRenewal();
    setLoading(false);
    return res;
  }, [submitRenewal]);

  return {
    eligibility,
    loading,
    checkEligibility,
    submitRenewal: requestRenewal,
  };
}

export function usePortalFreezes() {
  const { submitFreeze } = usePortalAuth();
  const [freezes, setFreezes] = useState([]);
  const [loading, setLoading] = useState(false);

  const loadFreezes = useCallback(async () => {
    setLoading(true);
    const res = await portalApi.requestFreeze({ preview: true });
    if (res?.success) setFreezes(res.data?.data || res.data || []);
    setLoading(false);
    return res;
  }, []);

  const handleSubmit = useCallback(async () => {
    setLoading(true);
    const res = await submitFreeze();
    setLoading(false);
    return res;
  }, [submitFreeze]);

  useEffect(() => {
    loadFreezes();
  }, [loadFreezes]);

  return { freezes, loading, refresh: loadFreezes, submitFreeze: handleSubmit };
}

export function usePortalPayments() {
  const { overview, loading, error, refresh } = usePortalOverview();
  const [invoiceLoading, setInvoiceLoading] = useState(false);

  const payments = useMemo(() => {
    return overview?.payments || [];
  }, [overview]);

  const printInvoice = useCallback(async (payload) => {
    setInvoiceLoading(true);
    const res = await portalApi.printInvoice(payload);
    setInvoiceLoading(false);
    return res;
  }, []);

  return { 
    payments, 
    loading, 
    error, 
    reload: refresh, 
    printInvoice,
    invoiceLoading 
  };
}

export function usePortalPerformance() {
  const [summary, setSummary] = useState(null);

  useEffect(() => {
    const load = async () => {
      const res = await portalApi.getRatingSummary();
      if (res?.success) setSummary(res.data?.summary || res.data?.data || res.data);
    };
    load();
  }, []);

  return { summary };
}

export function usePortalUniforms() {
  const [items, setItems] = useState([]);

  useEffect(() => {
    const load = async () => {
      const res = await portalApi.listUniformStore();
      if (res?.success) setItems(res.data?.data || res.data || []);
    };
    load();
  }, []);

  return { items };
}

export function usePortalOrders() {
  const [orders, setOrders] = useState([]);

  useEffect(() => {
    const load = async () => {
      const res = await portalApi.listMyUniformOrders();
      if (res?.success) setOrders(normalizeUniformOrders(res.data));
    };
    load();
  }, []);

  return { orders };
}

export function usePortalNews() {
  const [news, setNews] = useState([]);

  useEffect(() => {
    const load = async () => {
      const res = await portalApi.listNews();
      if (res?.success) {
        const raw = res.data;
        const list =
          Array.isArray(raw) ? raw :
            Array.isArray(raw?.news) ? raw.news :
              Array.isArray(raw?.data?.news) ? raw.data.news :
                Array.isArray(raw?.data) ? raw.data :
                  [];
        setNews(list);
      }

    };
    load();
  }, []);

  return { news };
}

export function usePasswordReset() {
  const { resetPassword, isLoading, error } = usePortalAuth();
  const [success, setSuccess] = useState(false);

  const requestReset = useCallback(
    async ({ academyId, username, phoneNumber }) => {
      setSuccess(false);
      const result = await resetPassword({ academyId, username, phoneNumber });
      if (result?.success) setSuccess(true);
      return result;
    },
    [resetPassword]
  );

  return { requestReset, isLoading, error, success };
}

export function useAcademies() {
  const mounted = useRef(true);

  const [loading, setLoading] = useState(true);
  const [academies, setAcademies] = useState([]);
  const [error, setError] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');

  const load = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);

      const res = await portalApi.fetchActiveAcademies();
      if (!res?.success) throw res?.error || new Error('Failed');

      const raw = res.data || {};
      const customers = Array.isArray(raw.customers)
        ? raw.customers
        : Array.isArray(raw?.data?.customers)
          ? raw.data.customers
          : [];

      const items = customers.map((c) => {
        const academyName = c.academy_name || '';
        const clientName = c.client_name || '';
        const label = c.label || `${academyName} — ${clientName}`.trim();

        return {
          id: Number(c.id),
          academy_name: academyName,
          client_name: clientName,
          label,
          name: academyName || label || 'Academy',
          subtitle: clientName || '',
          searchText: `${academyName} ${clientName} ${label}`.toLowerCase(),
        };
      });

      if (mounted.current) setAcademies(items);
      return items;
    } catch (e) {
      if (mounted.current) {
        setError(e);
        setAcademies([]);
      }
      return [];
    } finally {
      if (mounted.current) setLoading(false);
    }
  }, []);

  useEffect(() => {
    mounted.current = true;
    load();
    return () => {
      mounted.current = false;
    };
  }, [load]);

  const filtered = useMemo(() => {
    const q = (searchQuery || '').trim().toLowerCase();
    if (!q) return academies;
    return academies.filter((a) => (a.searchText || '').includes(q));
  }, [academies, searchQuery]);

  return {
    academies: filtered,
    loading,
    error,
    searchQuery,
    setSearchQuery,
    refresh: load,
  };
}

