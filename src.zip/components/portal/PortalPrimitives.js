// src/components/portal/PortalPrimitives.js
import React, { memo } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { colors, spacing, radius, typography, shadows, alphaBg } from '../../theme/portal.styles';

export const PortalScreen = ({ children, style }) => (
  <View style={[styles.screen, style]}>{children}</View>
);

export const PortalCard = ({ title, subtitle, right, children, style }) => (
  <View style={[styles.card, style]}>
    {(title || subtitle || right) ? (
      <View style={styles.cardHeader}>
        <View style={{ flex: 1 }}>
          {!!title && <Text style={styles.cardTitle}>{title}</Text>}
          {!!subtitle && <Text style={styles.cardSub}>{subtitle}</Text>}
        </View>
        {right}
      </View>
    ) : null}
    {children}
  </View>
);

export const PortalRow = memo(({ label, value, onPress, right, tone = 'default' }) => {
  const clickable = !!onPress;
  const Container = clickable ? Pressable : View;

  const bg =
    tone === 'soft'
      ? alphaBg(colors.primary, 0.08)
      : tone === 'danger'
        ? alphaBg(colors.error, 0.10)
        : 'transparent';

  return (
    <Container
      onPress={onPress}
      style={({ pressed }) => [
        styles.row,
        { backgroundColor: bg },
        clickable && pressed ? { opacity: 0.85, transform: [{ scale: 0.995 }] } : null,
      ]}
    >
      <View style={{ flex: 1 }}>
        <Text style={styles.rowLabel}>{label}</Text>
        <Text style={styles.rowValue} numberOfLines={2}>
          {value || '—'}
        </Text>
      </View>
      {right}
    </Container>
  );
});

export const PortalButton = memo(({ label, variant = 'primary', onPress, disabled, left }) => {
  const isPrimary = variant === 'primary';
  return (
    <Pressable
      onPress={onPress}
      disabled={disabled}
      style={({ pressed }) => [
        styles.btn,
        isPrimary ? styles.btnPrimary : styles.btnSecondary,
        disabled ? { opacity: 0.55 } : null,
        pressed && !disabled ? { transform: [{ scale: 0.99 }], opacity: 0.92 } : null,
      ]}
    >
      {left}
      <Text style={[styles.btnText, isPrimary ? styles.btnTextPrimary : styles.btnTextSecondary]}>
        {label}
      </Text>
    </Pressable>
  );
});

export const StickyBar = ({ children }) => <View style={styles.sticky}>{children}</View>;

export const InlineError = ({ text }) =>
  text ? (
    <View style={styles.errBox}>
      <Text style={styles.errText}>{text}</Text>
    </View>
  ) : null;

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: colors.backgroundDark,
  },
  card: {
    backgroundColor: colors.backgroundCard,
    borderRadius: radius.lg,
    borderWidth: 1,
    borderColor: colors.borderLight,
    padding: spacing.md,
    ...shadows.md,
  },
  cardHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: spacing.sm,
    marginBottom: spacing.sm,
  },
  cardTitle: {
    color: colors.textPrimary,
    fontFamily: typography.family.bold,
    fontSize: typography.sizes.lg,
  },
  cardSub: {
    marginTop: 2,
    color: colors.textSecondary,
    fontFamily: typography.family.regular,
    fontSize: typography.sizes.sm,
    lineHeight: typography.sizes.sm * 1.35,
  },
  row: {
    paddingVertical: spacing.sm,
    paddingHorizontal: spacing.sm,
    borderRadius: radius.md,
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
  },
  rowLabel: {
    color: colors.textTertiary,
    fontFamily: typography.family.medium,
    fontSize: typography.sizes.xs,
    marginBottom: 3,
  },
  rowValue: {
    color: colors.textPrimary,
    fontFamily: typography.family.regular,
    fontSize: typography.sizes.base,
  },
  btn: {
    height: 48,
    borderRadius: radius.md,
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'row',
    gap: spacing.sm,
    paddingHorizontal: spacing.md,
  },
  btnPrimary: {
    backgroundColor: colors.primary,
    ...shadows.glow,
  },
  btnSecondary: {
    backgroundColor: colors.backgroundElevated,
    borderWidth: 1,
    borderColor: colors.borderMedium,
  },
  btnText: {
    fontFamily: typography.family.medium,
    fontSize: typography.sizes.base,
  },
  btnTextPrimary: { color: colors.textInverted },
  btnTextSecondary: { color: colors.textPrimary },
  sticky: {
    position: 'absolute',
    left: spacing.screenPadding,
    right: spacing.screenPadding,
    bottom: spacing.screenPadding,
    padding: spacing.sm,
    borderRadius: radius.lg,
    backgroundColor: colors.backgroundOverlay,
    borderWidth: 1,
    borderColor: colors.borderMedium,
  },
  errBox: {
    marginTop: spacing.sm,
    padding: spacing.sm,
    borderRadius: radius.md,
    backgroundColor: alphaBg(colors.error, 0.14),
    borderWidth: 1,
    borderColor: alphaBg(colors.error, 0.35),
  },
  errText: {
    color: colors.textPrimary,
    fontFamily: typography.family.medium,
    fontSize: typography.sizes.sm,
  },
});
