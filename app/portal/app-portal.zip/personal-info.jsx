// app/portal/dashboard.jsx
import React from 'react';
import PersonalInfoScreen from '../../src/screens/portal/PersonalInfoScreen';

export default function PortalPersonalInfoRoute() {
  return <PersonalInfoScreen />;
}
