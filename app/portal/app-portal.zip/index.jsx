// app/portal/index.jsx
import { useRouter } from "expo-router";
import { useEffect } from "react";

export default function PortalIndex() {
  const router = useRouter();

  useEffect(() => {
    // if not logged in:
    router.replace("/portal/login");
  }, []);

  return null;
}
