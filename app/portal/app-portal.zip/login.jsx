import LoginScreen from '../../src/screens/portal/LoginScreen';

export default function PortalLoginRoute() {
  return <LoginScreen />;
}
