// app/portal/reset-password.jsx
import ResetPasswordScreen from '../../src/screens/portal/ResetPasswordScreen';

export default function PortalResetPasswordRoute() {
  return <ResetPasswordScreen />;
}
