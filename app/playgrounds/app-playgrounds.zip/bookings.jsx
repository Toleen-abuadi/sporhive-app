import React from 'react';
import { MyBookingsScreen } from '../../src/screens/playgrounds/MyBookingsScreen';

export default function MyBookingsRoute() {
  return <MyBookingsScreen />;
}
