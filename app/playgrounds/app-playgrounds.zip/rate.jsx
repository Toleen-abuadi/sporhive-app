import React from 'react';
import { VenueRatingScreen } from '../../src/screens/playgrounds/VenueRatingScreen';

export default function VenueRatingRoute() {
  return <VenueRatingScreen />;
}
