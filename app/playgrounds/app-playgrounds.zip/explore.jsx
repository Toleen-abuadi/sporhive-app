import React from 'react';
import { PlaygroundsExploreScreen } from '../../src/screens/playgrounds/PlaygroundsExploreScreen';

export default function PlaygroundsExploreRoute() {
  return <PlaygroundsExploreScreen />;
}
