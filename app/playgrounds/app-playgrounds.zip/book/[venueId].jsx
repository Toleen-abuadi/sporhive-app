import React from 'react';
import { BookingStepperScreen } from '../../../src/screens/playgrounds/BookingStepperScreen';

export default function BookingStepperRoute() {
  return <BookingStepperScreen />;
}
