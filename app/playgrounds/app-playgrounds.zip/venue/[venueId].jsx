import React from 'react';
import { VenueDetailsScreen } from '../../../src/screens/playgrounds/VenueDetailsScreen';

export default function VenueDetailsRoute() {
  return <VenueDetailsScreen />;
}
