import React from 'react';
import { PlaygroundsDiscoveryScreen } from '../../src/screens/PlaygroundsDiscoveryScreen';

export default function PlaygroundsIndex() {
  return <PlaygroundsDiscoveryScreen />;
}
