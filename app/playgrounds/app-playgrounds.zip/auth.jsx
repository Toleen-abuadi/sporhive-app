import React from 'react';
import { PlaygroundsAuthScreen } from '../../src/screens/playgrounds/PlaygroundsAuthScreen';

export default function PlaygroundsAuthRoute() {
  return <PlaygroundsAuthScreen />;
}
